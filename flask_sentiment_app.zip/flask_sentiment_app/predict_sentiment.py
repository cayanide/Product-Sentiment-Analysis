import joblib
from nltk.corpus import stopwords
from collections import Counter
import requests
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Fetch API key from environment variables
OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

# Load the model and vectorizer
NB_model = joblib.load('NB_model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# Preprocess the text
def preprocess_text(text):
    try:
        text = text.lower()
        stop_words = set(stopwords.words('english'))
        text = " ".join([word for word in text.split() if word not in stop_words])
        return text
    except Exception as e:
        print(f"Error in preprocessing text: {e}")
        return ""

# Predict sentiment for reviews
def predict_sentiment(reviews):
    try:
        if not reviews:
            print("No reviews to analyze.")
            return []

        processed_reviews = [preprocess_text(review) for review in reviews]
        reviews_TFIDF = vectorizer.transform(processed_reviews)
        predictions = NB_model.predict(reviews_TFIDF)
        return predictions
    except Exception as e:
        print(f"Error in predicting sentiment: {e}")
        return []

# Generate summary based on sentiments
def generate_summary(reviews, sentiments):
    try:
        sentiment_count = Counter(sentiments)
        total_reviews = len(sentiments)

        # Sentiment counts
        positive_count = sentiment_count.get('positive', 0)
        neutral_count = sentiment_count.get('neutral', 0)
        negative_count = sentiment_count.get('negative', 0)

        # Overall sentiment
        if positive_count > negative_count and positive_count > neutral_count:
            overall_rating = "Positive"
        elif negative_count > positive_count and negative_count > neutral_count:
            overall_rating = "Negative"
        else:
            overall_rating = "Neutral"

        # Call OpenRouter API to generate AI-based review
        ai_review = generate_ai_review(reviews, sentiments, overall_rating)

        return ai_review, overall_rating
    except Exception as e:
        print(f"Error in generating summary: {e}")
        return "Error generating summary.", "Unknown"

# Function to generate AI-based review using OpenRouter API
def generate_ai_review(reviews, sentiments, overall_rating):
    combined_reviews = "\n".join(reviews)
    prompt = (
        f"The product has the following reviews:\n{combined_reviews}\n\n"
        f"The overall sentiment is '{overall_rating.lower()}'. "
        f"Based on the reviews, write a detailed summary describing customers' opinions, "
        f"highlighting common praises and complaints."
    )

    try:
        # Use OpenRouter API for the request
        response = requests.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "meta-llama/llama-3.2-3b-instruct:free",
                "messages": [
                    {"role": "system", "content": "You are an assistant that summarizes customer reviews."},
                    {"role": "user", "content": prompt},
                ],
                "max_tokens": 150,
                "temperature": 0.7,
                "top_p": 1.0,
            }
        )

        # Check for successful response
        if response.status_code == 200:
            result = response.json()
            return result['choices'][0]['message']['content'].strip()
        else:
            print(f"Error from OpenRouter API: {response.status_code} - {response.text}")
            return "No detailed summary available for this product."

    except requests.exceptions.RequestException as e:
        print(f"Request error: {e}")
        return "An error occurred while connecting to OpenRouter."

# Example .env file content:
# OPENROUTER_API_KEY=your_openrouter_api_key
